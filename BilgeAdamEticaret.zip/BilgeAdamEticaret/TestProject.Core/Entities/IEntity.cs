﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestProject.Core.Entities
{
    public interface IEntity
    {
    }
}
